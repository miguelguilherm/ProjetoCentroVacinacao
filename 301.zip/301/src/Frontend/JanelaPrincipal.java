package Frontend;

import javax.swing.JOptionPane;
import Backend.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import serializacao.Serializacao;

public class JanelaPrincipal extends javax.swing.JFrame {

    private Sistema sistema;
    private Serializacao x;

    public JanelaPrincipal(Sistema sistema, Serializacao x) {
        initComponents();
        this.sistema = sistema;
        this.x = x;

        //Utilizador utilizadorLigado = sistema.getUtilizadorLigado();
        /*
            if (utilizadorLigado instanceof Administrador) {
            UtenteMenu.setVisible(false);
            GestorMenu.setVisible(false);

        } else if (utilizadorLigado instanceof Gestor) {
            AdminMenu.setVisible(false);
            UtenteMenu.setVisible(false);

        } else {
            AdminMenu.setVisible(false);
            GestorMenu.setVisible(false);
        }
         */
        //Força a maximização da janela
        this.setExtendedState(JanelaPrincipal.MAXIMIZED_BOTH);

        //O processo de fecho da janela será controlado pelo programa
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        //Apenas mostra o menu de administração se o utilizador for um administrador
        AdminMenu.setVisible(sistema.getUtilizadorLigado() instanceof Administrador);
        GestorMenu.setVisible(sistema.getUtilizadorLigado() instanceof Gestor);
        UtenteMenu.setVisible(sistema.getUtilizadorLigado() instanceof Utente);

    }

    public void guardarAlteracoes() {
        x.guardar(sistema);
    }

    public void alterarPassword() {
        MudarDados psw = new MudarDados(sistema, sistema.getUtilizadorLigado(), null);
        psw.setVisible(true);
    }

    private void terminar() {
        if (JOptionPane.showConfirmDialog(null,
                "Deseja realmente terminar o programa?",
                "Terminar",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            guardarAlteracoes();
            sistema.terminar();
            
            
            
            
        }
    }

    private void listarCentro() {
        ListarCentro perfil = new ListarCentro(sistema);
        perfil.setVisible(true);
    }

    private void listarGestores() {
        ListarGestor listagem = new ListarGestor(sistema);
        listagem.setVisible(true);
    }

    private void listarUtente() {
        ListarUtente listagem = new ListarUtente(sistema);
        listagem.setVisible(true);
    }

    private void listarVacina() {
        ListarVacina listagem = new ListarVacina(sistema);
        listagem.setVisible(true);
    }
    
    private void criarUtente(){
        CriarUtente utente = new CriarUtente(sistema, null, null);
        utente.setVisible(true);             
    }
    
    private void editarCentro(){
        EditarCentro centro = new EditarCentro(sistema, null, null);
        centro.setVisible(true);
    }
    
    public void criarUtilizador(){
        CriarUtilizador user = new CriarUtilizador(sistema, null, null);
        user.setVisible(true);
    }
    
    public void criarGestor(){
        CriarGestor gestor = new CriarGestor(sistema, null, null);
        gestor.setVisible(true);
    }
    
    public void criarCentro(){
        CriarCentroVacinacao centro = new CriarCentroVacinacao(sistema,null,null);
        centro.setVisible(true);
    }
    
    public void criarVacina(){
        CriarVacina vacina = new CriarVacina(sistema, null, null);
        vacina.setVisible(true);
    }
    
    public void listarStock(){
        ListarStock stock = new ListarStock(sistema);
        stock.setVisible(true);
    }
    
    public void registar(){
        Registo registo = new Registo(sistema, x);
        registo.setVisible(true);
    }
    
    private void setCentro(){
        try {
            if (sistema.getListaUtente().getUtente(sistema.getUtilizadorLigado().getUsername()).getCentro()== null)
            {
                RegistoCentro listagem;
                try {
                    listagem = new RegistoCentro(sistema, sistema.getListaUtente().getUtente(sistema.getUtilizadorLigado().getUsername()));
                    listagem.setVisible(true);
                } catch (ListaUtente.UtenteNaoExisteException ex) {
                    Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Já está associado a um centro");
            }   } catch (ListaUtente.UtenteNaoExisteException ex) {
            Logger.getLogger(JanelaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu6 = new javax.swing.JMenu();
        jAlterar = new javax.swing.JMenuItem();
        jFechar = new javax.swing.JMenuItem();
        AdminMenu = new javax.swing.JMenu();
        jCentro = new javax.swing.JMenuItem();
        jGestores = new javax.swing.JMenuItem();
        jUtentes = new javax.swing.JMenuItem();
        jVacinas = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        GestorMenu = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        UtenteMenu = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu6.setText("Geral");
        jMenu6.setFont(new java.awt.Font("PingFang SC", 0, 14)); // NOI18N

        jAlterar.setText("Alterar dados");
        jAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAlterarActionPerformed(evt);
            }
        });
        jMenu6.add(jAlterar);

        jFechar.setText("Fechar");
        jFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFecharActionPerformed(evt);
            }
        });
        jMenu6.add(jFechar);

        jMenuBar1.add(jMenu6);

        AdminMenu.setText("Admin");
        AdminMenu.setFont(new java.awt.Font("PingFang SC", 0, 14)); // NOI18N

        jCentro.setText("Centros");
        jCentro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCentroActionPerformed(evt);
            }
        });
        AdminMenu.add(jCentro);

        jGestores.setText("Gestores");
        jGestores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jGestoresActionPerformed(evt);
            }
        });
        AdminMenu.add(jGestores);

        jUtentes.setText("Utentes");
        jUtentes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUtentesActionPerformed(evt);
            }
        });
        AdminMenu.add(jUtentes);

        jVacinas.setText("Vacinas");
        jVacinas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jVacinasActionPerformed(evt);
            }
        });
        AdminMenu.add(jVacinas);

        jMenuItem10.setText("Stock");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        AdminMenu.add(jMenuItem10);

        jMenuBar1.add(AdminMenu);

        GestorMenu.setText("Gestor");
        GestorMenu.setFont(new java.awt.Font("PingFang SC", 0, 14)); // NOI18N

        jMenuItem3.setText("Centros");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        GestorMenu.add(jMenuItem3);

        jMenuItem8.setText("Utentes");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        GestorMenu.add(jMenuItem8);

        jMenuItem6.setText("Vacinas");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        GestorMenu.add(jMenuItem6);

        jMenuBar1.add(GestorMenu);

        UtenteMenu.setText("Utente");
        UtenteMenu.setFont(new java.awt.Font("PingFang SC", 0, 14)); // NOI18N

        jMenuItem1.setText("Registar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        UtenteMenu.add(jMenuItem1);

        jMenuItem2.setText("Centros ");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        UtenteMenu.add(jMenuItem2);

        jMenuItem5.setText("Doenças");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        UtenteMenu.add(jMenuItem5);

        jMenuBar1.add(UtenteMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jGestoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jGestoresActionPerformed
        // TODO add your handling code here:
        listarGestores();
    }//GEN-LAST:event_jGestoresActionPerformed

    private void jUtentesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUtentesActionPerformed
        // TODO add your handling code here:
        listarUtente();    
    }//GEN-LAST:event_jUtentesActionPerformed

    private void jCentroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCentroActionPerformed
        // TODO add your handling code here:
        listarCentro();
    }//GEN-LAST:event_jCentroActionPerformed

    private void jAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAlterarActionPerformed
        // TODO add your handling code here:
        alterarPassword();
    }//GEN-LAST:event_jAlterarActionPerformed

    private void jFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFecharActionPerformed
        // TODO add your handling code here:
        terminar();
    }//GEN-LAST:event_jFecharActionPerformed

    private void jVacinasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jVacinasActionPerformed
        // TODO add your handling code here:
        criarVacina();
        
    }//GEN-LAST:event_jVacinasActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:   
        setCentro();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        listarCentro();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
        listarUtente();
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        listarVacina();
        
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
        listarStock();
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        registar();
        
        
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        criarUtente();
    }//GEN-LAST:event_jMenuItem1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu AdminMenu;
    private javax.swing.JMenu GestorMenu;
    private javax.swing.JMenu UtenteMenu;
    private javax.swing.JMenuItem jAlterar;
    private javax.swing.JMenuItem jCentro;
    private javax.swing.JMenuItem jFechar;
    private javax.swing.JMenuItem jGestores;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jUtentes;
    private javax.swing.JMenuItem jVacinas;
    // End of variables declaration//GEN-END:variables
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frontend;
import Backend.*;
import javax.swing.JOptionPane;

import serializacao.Serializacao;

/**
 *
 * @author miguel
 */

public class Piloto {
    
    
    
     public static void main(String[] args) throws ListaUtilizador.UtilizadorDuplicadoException {
       
      
       
        Sistema sistema;        
        String ficheiroDados = String.format("%s\\utilizadores.data", System.getProperty("user.dir"));
        System.out.println(String.format("Ficheiro de dados: %s.", ficheiroDados));
        Serializacao x = new Serializacao(ficheiroDados);        
        
        //Se o ficheiro de base de dados nao existir
        if (! x.getFicheiro().exists()) {
            //Cria uma instancia do sistema
            sistema = new Sistema();      
            //Adiciona dois utilizadores para que possa ser possivel entrar no sistema 
            sistema.getListaUtilizador().adicionar(new Administrador("admin", "admin", 1234, "Administrador")); 
            sistema.getListaUtilizador().adicionar(new Utilizador("user2", "1234", "Utilizador 2"));
            
        }else{
           sistema = x.carregar();            
        }  
        
        

        Login login = new Login(sistema);               
        login.setVisible(true);
  
        JanelaPrincipal janela = new JanelaPrincipal(sistema, x);
        janela.setVisible(true);
             
        
    }          
    
    
}

package Backend;
import java.io.Serializable;

public class Administrador extends Utilizador implements Serializable{

  //
  
  private int numAdm;

  //
  public Administrador(String username, String password, int numAdm, String nome)
  {
    super(username, password, nome);
    this.numAdm = numAdm;
    
    
  }

// Getters e setters


 


  public int numAdm() {
    return numAdm;
  }
  public void setAdm(int numAdm) {
    this.numAdm = numAdm;
  }
}

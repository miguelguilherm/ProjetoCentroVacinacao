package Backend;
import java.util.*;
import java.time.*;
import java.io.*;



public class Marcacoes implements Serializable
{
  private HashMap<LocalDate, ArrayList<Utente>> agenda;

  public Marcacoes(HashMap<LocalDate,ArrayList<Utente>> agenda)
  {
    agenda = new HashMap<>();
  }

  public void marcar (LocalDate data, Utente utente)
  {
    ArrayList<Utente> agendamentos = agenda.get(data);
    if (agendamentos == null)
    {
      agendamentos = new ArrayList<>();
      agendamentos.add(utente);
      agenda.put(data,agendamentos);
    } else if (!agendamentos.contains(utente))
      {
        agendamentos.add(utente);
      }
   }
  public void cancelar (LocalDate data, Utente utente)
  {
    ArrayList<Utente> agendamentos = agenda.get(data);

    if (agendamentos != null && agendamentos.contains(utente))
    {
      agendamentos.remove(utente);
      if (agendamentos.isEmpty())
      {
        agenda.remove(data);
      }
    }
  }
  
  
  public HashMap getAgenda(){
      return agenda;
  }
  


  

}

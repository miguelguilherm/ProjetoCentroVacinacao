/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Backend;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class ListaStock implements Serializable 
{
    private HashMap<CentroVacinacao, Stock> lista;

    public class StockNaoExisteException extends Exception 
    {
        public StockNaoExisteException() { }
        public StockNaoExisteException(String message) 
        {
            super(message);
        }        
    }
    
    public class StockDuplicadoException extends Exception 
    {
        public StockDuplicadoException() { }
        public StockDuplicadoException(String message) 
        {
            super(message);
        }        
    }
    
    public ListaStock() 
    {
        lista = new HashMap<>();        
    }
    
    public void set_Stock (Stock stock) throws StockDuplicadoException 
    {
        if (stock == null) 
        {
            throw new NullPointerException("O parâmetro 'stock' não pode ser um valor nulo");
        }        
        
        if (!lista.containsKey(stock.get_Centro())) 
        {
            lista.put(stock.get_Centro(), stock);
        }
        else
        {
            throw new StockDuplicadoException(String.format("O stock '%s' já existe na coleção", stock.get_Centro()));
        }
        
    }        
    
    public boolean get_StockTrue (CentroVacinacao nome) 
    {
        return lista.containsKey(nome);
    }
    
    public int get_NumStocks () 
    {
        return lista.size();
    }
    
    public Stock get_Stock (CentroVacinacao nome) throws StockNaoExisteException {
        if (lista.containsKey(nome))
        {
            return lista.get(nome);
        }
        else
        {
            throw new StockNaoExisteException("O stock '%s' já existe na lista");
        }
    }
    public void apagar(CentroVacinacao nome)
    {
        lista.remove(nome);
    }
    public ArrayList<Stock> get_Stocks() 
    {
        return new ArrayList<>(lista.values());
    }
    
}



package Backend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;


public class ListaGestor implements Serializable {

    private HashMap<String, Gestor> lista_4;

    public class GestorNaoExisteException extends Exception {

        public GestorNaoExisteException() {
        }

        public GestorNaoExisteException(String message) {
            super(message);
        }
    }

    public class GestorDuplicadoException extends Exception {

        public GestorDuplicadoException() {
        }

        public GestorDuplicadoException(String message) {
            super(message);
        }
    }

    public ListaGestor() {
        lista_4 = new HashMap<>();
    }

    public void adicionar(Gestor gestor) throws GestorDuplicadoException {
        if (gestor == null) {
            throw new NullPointerException("O parâmetro 'gestor' não pode ser um valor nulo");
        }

        if (!lista_4.containsKey(gestor.getUsername())) {
            lista_4.put(gestor.getUsername(), gestor);
        } else {
            throw new GestorDuplicadoException(String.format("O gestor '%s' já existe na coleção", gestor.getUsername()));
        }

    }

    public boolean existe(String username) {
        return lista_4.containsKey(username);
    }

    public int size() {
        return lista_4.size();
    }

    public Gestor getGestor(String username) throws GestorNaoExisteException {
        if (lista_4.containsKey(username)) {
            return lista_4.get(username);
        } else {
            throw new GestorNaoExisteException("O gestor '%s' já existe na lista!");
        }
    }

    public ArrayList<Gestor> todos() {
        return new ArrayList<>(lista_4.values());
    }

    public void removerGestores(String codigo) {
        lista_4.remove(codigo);
    }

}

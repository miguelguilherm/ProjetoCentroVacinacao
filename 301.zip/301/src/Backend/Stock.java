package Backend;

import java.io.Serializable;
import java.util.HashMap;

public class Stock implements Serializable{

    private CentroVacinacao centroVacinacao;
    
    private HashMap<Vacina, Long> stock;

    public Stock(CentroVacinacao centroVacinacao) {
        stock = new HashMap<>();
    }

    public void set_Centro(CentroVacinacao centroVacinacao) {
        this.centroVacinacao = centroVacinacao;
    }

    public void set_StockVacina(Vacina vacina, Long quantidade) {
        stock.put(vacina, quantidade);
    }

    public void set_Remover(Vacina vacina) {
        stock.remove(vacina);
    }

    public CentroVacinacao get_Centro() {
        return centroVacinacao;
    }

    public HashMap<Vacina, Long> get_Stock() {
        return stock;
    }

    public long get_QuantidadeVacina(Vacina vacina) {
        return stock.get(vacina);
    }
}

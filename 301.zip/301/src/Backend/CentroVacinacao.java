package Backend;
import java.io.Serializable;


public class CentroVacinacao implements Serializable
{
  private String morada;
  private String cod_centro;
  private String localidade;
  private int numPostosAtendimento;
  
  
  

  public CentroVacinacao(String morada, String cod_centro, String localidade
          , int numPostosAtendimento)
  {
    this.morada = morada;
    this.cod_centro = cod_centro;
    this.localidade = localidade;
    this.numPostosAtendimento = numPostosAtendimento;
    
    
  }

  // Getters e setters

  public String getMorada()
  {
        return morada;
  }
  public void setMorada(String morada)
  {
        this.morada = morada;
  }


  public String getCod_Centro()
  {
        return cod_centro;
  }
  public void setCod_Centro(String cod_centro)
  {
        this.cod_centro = cod_centro;
  }


  public String getLocalidade()
  {
        return localidade;
  }
  public void setLocalidade(String localidade)
  {
        this.localidade = localidade;
  }




  public int getNumPostosAtendimento()
  {
        return numPostosAtendimento;
  }
  public void setNumPostosAtendimento(int numPostosAtendimento)
  {
        this.numPostosAtendimento = numPostosAtendimento;
  }
}

package Backend;
import java.io.Serializable;

public class Utente extends Utilizador implements Serializable 
{
  
  private String morada;
  private String localidade;
  private String data_nascimento;
  private int numTlm;
  private String email;
  private int numSNS;
  private CentroVacinacao centro;
  
  
  public Utente(){}



  public Utente(String username, String password, String morada, int numSNS, String localidade,
    String data_nascimento, int numTlm, String email, String nome, CentroVacinacao centro)
    {
        
        super(username, password, nome);
        this.morada = morada;
        this.numSNS = numSNS;
        this.localidade = localidade;
        this.data_nascimento = data_nascimento;
        this.numTlm = numTlm;
        this.email = email;
        this.centro = centro;
	
    }



  

// Getters e setters



  public String getMorada()
  {
       return morada;
  }
  public void setMorada(String morada)
  {
    this.morada = morada;
  }


  public String getLocalidade()
  {
       return localidade;
  }
  public void setLocalidade(String localidade)
  {
    this.localidade = localidade;
  }


  public String getData_nascimento()
  {
       return data_nascimento;
  }
  public void setData_nascimento(String data_nascimento)
  {
    this.data_nascimento = data_nascimento;
  }


  public int getNumTlm()
  {
       return numTlm;
  }
  public void setNumTlm(int numTlm)
  {
    this.numTlm = numTlm;
  }


  public String getEmail()
  {
       return email;
  }
  public void setEmail(String email)
  {
    this.email = email;
  }


  public int getNumSNS()
  {
       return numSNS;
  }
  public void setNumSNS(int numSNS)
  {
    this.numSNS = numSNS;
  }
  
   public void setCentro(CentroVacinacao centro)
    {
        this.centro = centro;
    }
   
    public CentroVacinacao getCentro()
    {
        return centro;
    }
}

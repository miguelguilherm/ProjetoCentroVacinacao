package Backend;
import java.util.*;
import java.io.*;
import Backend.*;

public class Sistema implements Serializable
{
  private final ListaUtilizador utilizador;
  private Utilizador utilizadorLigado;
  private final ListaCentroVacinacao centro;
  private CentroVacinacao centroSelecionado;
  private final ListaGestor gestor;
  private final ListaUtente utente;
  private final ListaVacina stock;
  private ListaStock stocks;
 
  public Sistema()
  {
    utilizador = new ListaUtilizador();
    centro = new ListaCentroVacinacao();
    stock = new ListaVacina();
    gestor = new ListaGestor();
    utente = new ListaUtente();
    stocks = new ListaStock();
  }
  
    public ListaStock getListaStock()
    {
        return stocks;
    }
  public CentroVacinacao getCentroSelecionado() {
      return centroSelecionado;
  }

  public void setCentroSelecionado(CentroVacinacao centroSelecionado) {
      this.centroSelecionado = centroSelecionado;
  }
  
   public ListaGestor getListaGestor() {
        return gestor;
    }

   public ListaUtente getListaUtente(){
       return utente;
   }

  public ListaVacina getListaVacina(){
      return stock;
  }
  
  public ListaUtilizador getListaUtilizador() {
      return utilizador;
  }

  public ListaCentroVacinacao getListaCentroVacinacao() {
      return centro;
  }

  public boolean autenticarUtilizador(String username, String password) {
      if (utilizador.existe(username)) {
          try{
              Utilizador u = utilizador.getUtilizador(username);
              if (u.getPassword().equals(password)){
                  utilizadorLigado = u;
                  return true;
              }
          } catch (Exception e) {}
      }
      return false;
  }

  public Utilizador getUtilizadorLigado() {
      return utilizadorLigado;
  }

  public void inicializar() throws ListaUtilizador.UtilizadorDuplicadoException {
      utilizador.adicionar(new Administrador("admin", "admin", 1234, "Administrador"));
      utilizador.adicionar(new Utilizador("user1", "1234", "Utilizador 1"));
      utilizador.adicionar(new Utilizador("user2", "1234", "Utilizador 2"));
  }

  public void terminar() {
      System.exit(0);
  }

    
}



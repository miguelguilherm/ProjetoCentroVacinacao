/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Backend;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author miguel
 */
public class ListaUtente implements Serializable {
    private HashMap<String, Utente> lista_5;

    public class UtenteNaoExisteException extends Exception {

        public UtenteNaoExisteException() {
        }

        public UtenteNaoExisteException(String message) {
            super(message);
        }
    }

    public class UtenteDuplicadoException extends Exception {

        public UtenteDuplicadoException() {
        }

        public UtenteDuplicadoException(String message) {
            super(message);
        }
    }

    public ListaUtente() {
        lista_5 = new HashMap<>();
    }

    public void adicionar(Utente utente) throws UtenteDuplicadoException {
        if (utente == null) {
            throw new NullPointerException("O parâmetro 'utente' não pode ser um valor nulo");
        }

        if (!lista_5.containsKey(utente.getUsername())) {
            lista_5.put(utente.getUsername(), utente);
        } else {
            throw new UtenteDuplicadoException(String.format("O utente '%s' já existe na coleção", utente.getUsername()));
        }

    }

    public boolean existe(String username) {
        return lista_5.containsKey(username);
    }

    public int size() {
        return lista_5.size();
    }

    public Utente getUtente(String username) throws UtenteNaoExisteException {
        if (lista_5.containsKey(username)) {
            return lista_5.get(username);
        } else {
            throw new UtenteNaoExisteException("O utente '%s' já existe na lista!");
        }
    }

    public ArrayList<Utente> todos() {
        return new ArrayList<>(lista_5.values());
    }

    public void removerUtentes(String codigo) {
        lista_5.remove(codigo);
    }

}



package Backend;

import java.io.Serializable;

public class Gestor extends Utilizador implements Serializable {

    private int numGestor;
    private CentroVacinacao centroVacinacao;

    public Gestor(String username, String password, int numGestor, String nome, CentroVacinacao centroVacinacao) {
        super(username, password, nome);
        this.numGestor = numGestor;
        this.centroVacinacao = centroVacinacao;
    }

// Getters e setters
    public int getNumGestor() {
        return numGestor;
    }

    public void setNumGestor(int numGestor) {
        this.numGestor = numGestor;
    }

    public CentroVacinacao getCentrovacinacao() {
        return centroVacinacao;
    }

    public void setCentroVacinacao(CentroVacinacao centroVacinacao) {
        this.centroVacinacao = centroVacinacao;
    }

}

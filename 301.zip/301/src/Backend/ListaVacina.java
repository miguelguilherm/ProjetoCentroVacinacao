package Backend;

import java.util.*;
import Backend.Vacina;
import java.io.*;

public class ListaVacina implements Serializable {

    private HashMap<String, Vacina> lista_2;

    public class VacinaNaoExisteException extends Exception {

        public VacinaNaoExisteException() {
        }

        public VacinaNaoExisteException(String message) {
            super(message);
        }
    }

    public class VacinaDuplicadoException extends Exception {

        public VacinaDuplicadoException() {
        }

        public VacinaDuplicadoException(String message) {
            super(message);
        }
    }

    public ListaVacina() {
        lista_2 = new HashMap<>();
    }

    public void adicionar(Vacina vacina) throws VacinaDuplicadoException {
        if (vacina == null) {
            throw new NullPointerException(" Vacina não pode ter valor nulo");
        }
        if (!lista_2.containsKey(vacina.getCod_vac())) {
            lista_2.put(vacina.getCod_vac(), vacina);
        } else {
            throw new VacinaDuplicadoException(String.format("A vacina '%s' já existe", vacina.getCod_vac()));
        }
    }

    public boolean existe(String Cod_Centro) {
        return lista_2.containsKey(Cod_Centro);
    }

    public Vacina getVacina(String cod_vac) throws VacinaNaoExisteException {
        if (lista_2.containsKey(cod_vac)) {
            return lista_2.get(cod_vac);
        } else {
            throw new VacinaNaoExisteException("A vacina '%s' já existe ");
        }
    }

    public int size() {
        return lista_2.size();
    }

    public ArrayList<Vacina> todos() {
        return new ArrayList<>(lista_2.values());
    }

//remover Vacina
    public void removerVacina(String cod_vac) {
        lista_2.remove(cod_vac);
    }
}

package Backend;
import java.util.*;
import Backend.CentroVacinacao;
import java.io.*;

public class ListaCentroVacinacao implements Serializable
{
  private HashMap<String, CentroVacinacao > lista_3;
  
  public class CentroVacinacaoNaoExisteException extends Exception 
  {
       public CentroVacinacaoNaoExisteException() { }
       public CentroVacinacaoNaoExisteException(String message) 
       {
            super(message);
       }        
  }
    
  public class CentroVacinacaoDuplicadoException extends Exception 
  {
        public CentroVacinacaoDuplicadoException() { }
        public CentroVacinacaoDuplicadoException(String message) 
        {
            super(message);
        }        
  }
    


  public ListaCentroVacinacao()
  {
    lista_3 = new HashMap<>();
  }

  public void adicionar(CentroVacinacao centroVacinacao) throws CentroVacinacaoDuplicadoException
  {
    if (centroVacinacao == null)
    {
        throw new NullPointerException("O parâmetro 'centroVacinacao' não pode ser um valor nulo");
    }
    if (!lista_3.containsKey(centroVacinacao.getCod_Centro())) {
            lista_3.put(centroVacinacao.getCod_Centro(), centroVacinacao);
        }else{
            throw new CentroVacinacaoDuplicadoException(String.format("O Centro '%s' já existe", centroVacinacao.getCod_Centro()));
        }
  }


  public boolean existe(String Cod_Centro) 
    {
        return lista_3.containsKey(Cod_Centro);
    }

  public CentroVacinacao getCentroVacinacao(String Cod_Centro) throws CentroVacinacaoNaoExisteException
  { 
    if (lista_3.containsKey(Cod_Centro))
    {
        return lista_3.get(Cod_Centro);
    }
    else 
    {
        throw new CentroVacinacaoNaoExisteException("O centro '%s' já existe ");
    }
  }

   public int size() {
        return lista_3.size();
    }
    
    public ArrayList<CentroVacinacao> todos() {
        return new ArrayList<>(lista_3.values());
    }
//remover CentroVacinacao

  public void removerCentroVacinacao(String codigo)
  {
      lista_3.remove(codigo);
  }
}

package Backend;
import java.io.Serializable;

public class Vacina implements Serializable {

    private String Designacao;
    private String cod_vac;
    private String fabricante;
    private int dose;
    private String tipo_toma;
    private int limite_min;
    private int limite_max;
   

    public Vacina(String designacao, String cod_vac, String fabricante, int dose, String tipo_toma, 
            int limite_min, int limite_max) {
        this.Designacao = designacao;
        this.cod_vac = cod_vac;
        this.fabricante = fabricante;
        this.dose = dose;
        this.tipo_toma = tipo_toma;
        this.limite_min = limite_min;
        this.limite_max = limite_max;
        
    }

    public String getDesignacao() {
        return Designacao;
    }

    public void setDesignacao(String designacao) {
        this.Designacao = designacao;
    }

    public String getCod_vac() {
        return cod_vac;
    }

    public void setCod_vac(String cod_vac) {
        this.cod_vac = cod_vac;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public float getDose() {
        return dose;
    }

    public void setDose(int dose) {
        this.dose = dose;
    }

    public String getTipo_toma() {
        return tipo_toma;
    }

    public void setTipo_toma(String tipo_toma) {
        this.tipo_toma = tipo_toma;
    }

    public int getLimite_min() {
        return limite_min;
    }

    public void setLimite_min(int limite_min) {
        this.limite_min = limite_min;
    }

    public int getLimite_max() {
        return limite_max;
    }

    public void setLimite_max(int limite_max) {
        this.limite_max = limite_max;
    }

 
}

package Backend;

import java.util.*;
import Backend.Utilizador;
import java.io.*;

public class ListaUtilizador implements Serializable {

    private HashMap<String, Utilizador> lista;

    public class UtilizadorNaoExisteException extends Exception {

        public UtilizadorNaoExisteException() {
        }

        public UtilizadorNaoExisteException(String message) {
            super(message);
        }
    }

    public class UtilizadorDuplicadoException extends Exception {

        public UtilizadorDuplicadoException() {
        }

        public UtilizadorDuplicadoException(String message) {
            super(message);
        }
    }

    public ListaUtilizador() {
        lista = new HashMap<>();
    }

    public void adicionar(Utilizador utilizador) throws UtilizadorDuplicadoException {
        if (utilizador == null) {
            throw new NullPointerException("Utilizador não pode ter valor nulo");
        }
        if (!lista.containsKey(utilizador.getUsername())) {
            lista.put(utilizador.getUsername(), utilizador);
        } else {
            throw new UtilizadorDuplicadoException(String.format("O utilizador '%s' já existe", utilizador.getUsername()));
        }
    }

    public boolean existe(String username) {
        return lista.containsKey(username);
    }

    public Utilizador getUtilizador(String username) throws UtilizadorNaoExisteException {
        if (lista.containsKey(username)) {
            return lista.get(username);

        } else {
            throw new UtilizadorNaoExisteException("O utilizador '%s' já existe ");
        }

    }

    public int size() {
        return lista.size();
    }

    public ArrayList<Utilizador> todos() {
        return new ArrayList<>(lista.values());
    }

//remover Utilizador
    public void removerUtilizador(String codigo) {
        lista.remove(codigo);
    }
}
